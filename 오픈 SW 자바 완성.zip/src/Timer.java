import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Timer extends JLabel implements Runnable {

	private QuizPanel quizPanel;
	public Timer(QuizPanel quizPanel) {
		this.quizPanel = quizPanel;
	}

	public synchronized void run() {
		int i = 10;
		ImageIcon imgSec = null;
		//String j = new String();
		while (true) {
			try {
				System.out.println(i);
				Thread.sleep(1000);
				if(i==10) imgSec = new ImageIcon("10.jpg");
				if(i==9) imgSec = new ImageIcon("9.jpg");
				if(i==8) imgSec = new ImageIcon("8.jpg");
				if(i==7) imgSec = new ImageIcon("7.jpg");
				if(i==6) imgSec = new ImageIcon("6.jpg");
				if(i==5)imgSec = new ImageIcon("5.jpg");
				if(i==4)imgSec = new ImageIcon("4.jpg");
				if(i==3)imgSec = new ImageIcon("3.jpg");
				if(i==2)imgSec = new ImageIcon("2.jpg");
				if(i==1)imgSec = new ImageIcon("1.jpg");
				if(i==0)imgSec = new ImageIcon("0.jpg");
				this.setIcon(imgSec);
				i--;
			} catch (InterruptedException exception) {
				exception.printStackTrace();
			}
			if(quizPanel.getIsTimeover()==false && quizPanel.getIsOX() == true){
				break;
			}
			if(i==-1){
				quizPanel.ox(-1);
				break;
			}
		}
	}
	

}
