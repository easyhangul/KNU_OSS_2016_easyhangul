import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LevelPanel extends JPanel {

	private JLabel backgroundLbl = null;

	public LevelPanel() {
		ImageIcon backgroundIcon = new ImageIcon("level.jpg");
		backgroundLbl = new JLabel();
		backgroundLbl.setIcon(backgroundIcon);
		this.add(backgroundLbl);
		backgroundLbl.setBounds(0, 0, 800, 800);
	}
}
