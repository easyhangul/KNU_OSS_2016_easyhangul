import java.awt.BorderLayout;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class QuizPanel extends JPanel {

	private ImageIcon imgBackground = new ImageIcon("background.jpg");
	private JLabel backgroundLabel;

	private JLabel img;
	private JLabel ex1;
	private JLabel ex2;

	private ImageIcon O = new ImageIcon("o.jpg");
	private ImageIcon X = new ImageIcon("x.jpg");
	private ImageIcon imgTimeover = new ImageIcon("timeover.jpg");

	private ImageIcon imgIcon0;
	private ImageIcon imgIcon1;
	private ImageIcon imgIcon2;
	private ImageIcon imgIcon3;
	private ImageIcon imgIcon4;
	private ImageIcon[] imgIcon = new ImageIcon[5];

	private String[] string1 = new String[5];
	private String[] string2 = new String[5];
	
	private File file0;
	private File file1;
	private File file2;
	private File file3;
	private File file4;
	private File[] file = new File[5];
	
	private AudioInputStream ais;
	private Clip clip;

	private int[] correctAnswer = new int[5];

	private int currIdx = -1;

	private boolean isOX = false;
	private boolean isTimeOver = false;
	
	private int score = 0;
	
	

	public enum Level {
		EASY, NORMAL, HARD
	};

	Level level;
	
	Font origiFont = new Font("����", Font.PLAIN, 20);
	Font pointFont = new Font("����", Font.BOLD, 30);
	
	private ExecutorService threadExecutor;
	private Timer timer;
	
	public QuizPanel() {
		img = new JLabel();
		ex1 = new JLabel();
		ex2 = new JLabel();
		backgroundLabel = new JLabel();
		threadExecutor = Executors.newCachedThreadPool();
		timer = new Timer(this);
	}

	public boolean getIsOX() {
		return isOX;
	}

	public void setIsOX(boolean isOX) {
		this.isOX = isOX;
	}

	public int getCurrIdx() {
		return currIdx;
	}

	public void setCurrIdx(int currIdx) {
		this.currIdx = currIdx;
	}

	public void setLevel(Level level) {

		this.level = level;
		System.out.println(level);
	}
	public ExecutorService getThreadExecutor() {
		return threadExecutor;
	}


	public void setImgNEx() {
		switch (level) {
		case EASY:
			imgIcon0 = new ImageIcon("e-1.jpg");
			imgIcon1 = new ImageIcon("e-2.jpg");
			imgIcon2 = new ImageIcon("e-3.jpg");
			imgIcon3 = new ImageIcon("e-4.jpg");
			imgIcon4 = new ImageIcon("e-5.png");
			file0 = new File("e-1.wav");
			file1 = new File("e-2.wav");
			file2 = new File("e-3.wav");
			file3 = new File("e-4.wav");
			file4 = new File("e-5.wav");

			string1[0] = "���̰� ����";
			string1[1] = "��Ȱ��";
			string1[2] = "������";
			string1[3] = "��������";
			string1[4] = "���Ҿ�";
			string2[0] = "���ǰ� ����";
			string2[1] = "������";
			string2[2] = "������";
			string2[3] = "��������";
			string2[4] = "���Ҿ�";
			correctAnswer[0] = 1;
			correctAnswer[1] = 2;
			correctAnswer[2] = 1;
			correctAnswer[3] = 2;
			correctAnswer[4] = 1;
			break;
		case NORMAL:
			imgIcon0 = new ImageIcon("n-1.jpg");
			imgIcon1 = new ImageIcon("n-2.png");
			imgIcon2 = new ImageIcon("n-3.png");
			imgIcon3 = new ImageIcon("n-4.jpg");
			imgIcon4 = new ImageIcon("n-5.jpg");
			file0 = new File("n-1.wav");
			file1 = new File("n-2.wav");
			file2 = new File("n-3.wav");
			file3 = new File("n-4.wav");
			file4 = new File("n-5.wav");
			string1[0] = "�ƿ�";
			string1[1] = "��";
			string1[2] = "�ǵ帮��";
			string1[3] = "������";
			string1[4] = "���Ա�";
			string2[0] = "�Ŀ�";
			string2[1] = "��";
			string2[2] = "�ǵ�����";
			string2[3] = "������";
			string2[4] = "���α�";
			correctAnswer[0] = 2;
			correctAnswer[1] = 2;
			correctAnswer[2] = 1;
			correctAnswer[3] = 2;
			correctAnswer[4] = 1;
			break;
		case HARD:
			imgIcon0 = new ImageIcon("h-1.png");
			imgIcon1 = new ImageIcon("h-2.jpg");
			imgIcon2 = new ImageIcon("h-3.jpg");
			imgIcon3 = new ImageIcon("h-4.jpg");
			imgIcon4 = new ImageIcon("h-5.jpeg");
			file0 = new File("h-1.wav");
			file1 = new File("h-2.wav");
			file2 = new File("h-3.wav");
			file3 = new File("h-4.wav");
			file4 = new File("h-5.wav");
			string1[0] = "������";
			string1[1] = "������";
			string1[2] = "�����ϳ�";
			string1[3] = "�ݼ�";
			string1[4] =  "�Ǽ�";
			string2[0] = "��ٴ��";
			string2[1] = "����ġ";
			string2[2] = "����ϳ�";
			string2[3] = "�ݻ�";
			string2[4] ="�ż�";
			correctAnswer[0] = 2;
			correctAnswer[1] = 1;
			correctAnswer[2] = 1;
			correctAnswer[3] = 1;
			correctAnswer[4] = 2;
		}
		imgIcon[0] = imgIcon0;
		imgIcon[1] = imgIcon1;
		imgIcon[2] = imgIcon2;
		imgIcon[3] = imgIcon3;
		imgIcon[4] = imgIcon4;
		file[0] = file0;
		file[1] = file1;
		file[2] = file2;
		file[3] = file3;
		file[4] = file4;
		
		backgroundLabel.setIcon(imgBackground);
		this.add(img);
		this.add(ex1);
		this.add(ex2);
		this.add(timer);
		this.add(backgroundLabel);
		
		img.setBounds(100, 100, 600, 400);
		ex1.setBounds(150, 500, 300, 100);
		ex2.setBounds(450, 500, 300, 100);
		backgroundLabel.setBounds(0, 0, 800, 800);
		timer.setBounds(400, 20, 80, 100);
		
	}
	
	public synchronized void playSound(){
		System.out.println("play"+currIdx);
		try {
			ais = AudioSystem.getAudioInputStream(file[currIdx]);
			clip = AudioSystem.getClip();
			clip.open(ais);
			clip.start();
		} catch (UnsupportedAudioFileException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	
	public void nextQuiz() {
		if(currIdx != -1)
			clip.stop();
		currIdx++;
		img.setIcon(imgIcon[currIdx]);
		ex1.setText(string1[currIdx]);	
		ex2.setText(string2[currIdx]);
		ex1.setFont(origiFont);
		ex2.setFont(origiFont);
		timer.setFont(origiFont);
		setIsOX(false);
		setIsTimeover(false);
		playSound();
		threadExecutor.execute(timer);
	}
	
	public void changeFontSize(int x){
		if(x<400){
			ex1.setFont(pointFont);
			ex2.setFont(origiFont);
		}
		else{
			ex1.setFont(origiFont);
			ex2.setFont(pointFont);
		}
	}

	public void ox(int x) {
		if(x==-1){
			img.setIcon(imgTimeover);
			ex1.setFont(origiFont);
			ex2.setFont(origiFont);
			setIsOX(false);
			setIsTimeover(true);
		}
		else if ((x < 400 && correctAnswer[currIdx] == 1) || (x > 400 && correctAnswer[currIdx] == 2)){
			img.setIcon(O);
			setIsOX(true);
			setIsTimeover(false);
			setScore(score+10);
			System.out.println("score" + score);
		}
		else{
			img.setIcon(X);
			setIsOX(true);
			setIsTimeover(false);
		}
	}

	public void setIsTimeover(boolean isTimeOver) {
		this.isTimeOver = isTimeOver;
	}

	public boolean getIsTimeover() {
		return isTimeOver;
	}
	public void setScore(int score){
		this.score = score;
	}
	public int getScore() {
		System.out.println("**"+score);
		return score;
	}
}