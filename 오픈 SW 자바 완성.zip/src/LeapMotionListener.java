import com.leapmotion.leap.*;
import com.leapmotion.leap.Gesture.State;
import com.leapmotion.leap.Gesture.Type;

public class LeapMotionListener extends Listener {

	private MainFrame mainFrame = null;

	private int clapCnt = 0;
	private float min = 30;
	private boolean clap = false;

	public LeapMotionListener(MainFrame mainFrame) {
		this.mainFrame = mainFrame;
	}

	public void onInit(Controller controller) {
		System.out.println("Initialized");
	}

	public void onConnect(Controller controller) {
		System.out.println("Connected to Motion Sensor");
		controller.enableGesture(Gesture.Type.TYPE_CIRCLE);
		controller.enableGesture(Gesture.Type.TYPE_SWIPE);
		// controller.enableGesture(Gesture.Type.TYPE_KEY_TAP);
		controller.enableGesture(Gesture.Type.TYPE_SCREEN_TAP);
	}

	public void onDisconnect(Controller controller) {
		System.out.println("Motion Sensor Disconnected");
	}

	public void onExit(Controller controller) {
		System.out.println("Exited");
	}

	public void onFrame(Controller controller) {
		Frame frame = controller.frame();

		// resultPanel - �ڼ� 3��ġ�� level �гη� ��ȯ
		if (mainFrame.getCurrentPanel() == mainFrame.getResultPanel()) {
		
			
			for (Hand hand : frame.hands()) {
				if (frame.hands().count() == 2) {
					Hand hand1 = frame.hands().get(0);
					Hand hand2 = frame.hands().get(1);
					Float distance = hand1.palmPosition().distanceTo(hand2.palmPosition());

					if (distance < 30 && !clap) {
						if (min > distance) {
							min = distance;
						} else {
							clapCnt++;
							clap = true;
							System.out.println("�ڼ� " + clapCnt + "��");
							mainFrame.getResultPanel().numOfClap(clapCnt);
						}
						if (clapCnt == 3) {
							mainFrame.changePanel(1);
							clapCnt = 0;
						}
					} else if (distance >= 30 && clap) {
						min = 30;
						clap = false;
					}

				}
			}
		}

		// homePanel - screen tap�ϸ� level �гη� ��ȯ
		if (mainFrame.getCurrentPanel() == mainFrame.getHomePanel())
			for (Gesture gesture : frame.gestures())
				if (gesture.type() == Type.TYPE_SCREEN_TAP)
					mainFrame.changePanel(1);

		// levelPanel - swipe�� ���⿡ ���� level ���� & ����
		if (mainFrame.getCurrentPanel() == mainFrame.getLevelPanel())
			mainFrame.getResultPanel().setIClapLabel();
			for (Gesture gesture : frame.gestures()) {
				if (gesture.type() == Type.TYPE_SWIPE && gesture.state() == State.STATE_STOP) {
					SwipeGesture swipeGesture = new SwipeGesture(gesture);
					Vector swipeVector = swipeGesture.direction();
					float dirX = swipeVector.getX();
					float dirY = swipeVector.getY();
				
					if (dirX > 0.9) {// right
						mainFrame.getQuizPanel().setLevel(mainFrame.getQuizPanel().level.EASY);
						mainFrame.getQuizPanel().setImgNEx();
						mainFrame.getQuizPanel().nextQuiz();mainFrame.changePanel(2);
					} else if (dirY < -0.9) {// down
						mainFrame.getQuizPanel().setLevel(mainFrame.getQuizPanel().level.NORMAL);
						mainFrame.getQuizPanel().setImgNEx();
						mainFrame.getQuizPanel().nextQuiz();mainFrame.changePanel(2);
					} else if (dirX < -0.9) {// left
						mainFrame.getQuizPanel().setLevel(mainFrame.getQuizPanel().level.HARD);
						mainFrame.getQuizPanel().setImgNEx();
						mainFrame.getQuizPanel().nextQuiz();mainFrame.changePanel(2);
					} else if (dirY > 0.9) {// up
						System.out.println("exit");
						System.exit(0);
					}
					
				}
			}

		// quizPanel - 1)img : ������� �������� ���� ��ġ �ľ�&screen tap -> �ش��ϴ� ���⸦ ������ ����
		// or ������ ������ ��� result �гη� ��ȯ
		// 2)img : circle -> ���� ���
		// 3)o or x : screen tap -> ���� ����
		if (mainFrame.getCurrentPanel() == mainFrame.getQuizPanel()) {
			if (mainFrame.getQuizPanel().getIsOX() == false && mainFrame.getQuizPanel().getIsTimeover() == false){
				for (Hand hand : frame.hands()) {
					InteractionBox box = frame.interactionBox();
					Vector position = hand.stabilizedPalmPosition();
					Vector boxFingerPos = box.normalizePoint(position);

					int x = (int) (800 * boxFingerPos.getX());

					mainFrame.getQuizPanel().changeFontSize(x);

					for (Gesture gesture : frame.gestures()) {

						if (gesture.type() == Type.TYPE_SCREEN_TAP && gesture.state() == State.STATE_STOP) {
							System.out.println(mainFrame.getQuizPanel().getCurrIdx());
						
								mainFrame.getQuizPanel().ox(x);
						
						}

						if (gesture.type() == Type.TYPE_CIRCLE && gesture.state() == State.STATE_STOP) {
							System.out.println("c");
							mainFrame.getQuizPanel().playSound();
						}
					}
				}
			} 
			
			else {
				for (Gesture gesture : frame.gestures()) {
					if (gesture.type() == Type.TYPE_SCREEN_TAP && gesture.state() == State.STATE_STOP) {
						if (mainFrame.getQuizPanel().getCurrIdx() == 4) {
							mainFrame.getQuizPanel().setCurrIdx(-1);
							mainFrame.getResultPanel().printScore();
							mainFrame.changePanel(3);
						} else
							mainFrame.getQuizPanel().nextQuiz();
					}
				}
			}
			
			
			
		} // end of onFrame method

	}
}// end of mainListener class
