import javax.swing.*;

import com.leapmotion.leap.Controller;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.*;

public class MainFrame extends JFrame {

	private HomePanel homePanel = new HomePanel();
	private LevelPanel levelPanel = new LevelPanel();
	private QuizPanel quizPanel = new QuizPanel();
	private ResultPanel resultPanel = new ResultPanel(this);
	private JPanel[] panelArr = { homePanel, levelPanel, quizPanel, resultPanel };

	private JPanel currentPanel = null;

	public MainFrame() {
		this.setLayout(null);
		this.setSize(800, 800);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("�ѱ� ����� ����");

		currentPanel = panelArr[0];
		currentPanel.setBounds(0, 0, 800, 800);
		currentPanel.setLayout(null);

		this.setContentPane(currentPanel);
		this.setVisible(true);
		this.setResizable(false);
	}

	public JPanel getCurrentPanel() {
		return currentPanel;
	}

	public HomePanel getHomePanel() {
		return homePanel;
	}

	public LevelPanel getLevelPanel() {
		return levelPanel;
	}

	public QuizPanel getQuizPanel() {
		return quizPanel;
	}

	public ResultPanel getResultPanel() {
		return resultPanel;
	}

	public synchronized void changePanel(int i) {
		currentPanel = panelArr[i];
		currentPanel.setBounds(0, 0, 800, 800);
		currentPanel.setLayout(null);
		this.setContentPane(currentPanel);
	}
}
