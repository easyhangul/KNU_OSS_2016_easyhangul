import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ResultPanel extends JPanel {

	private MainFrame frame;
	private ImageIcon imgBackground = new ImageIcon("background.jpg");
	private ImageIcon imgClap = new ImageIcon("clap.jpg");
	private ImageIcon imgEmpty = new ImageIcon("empty.jpg");
	private JLabel backgroundLabel;
	private JLabel scoreLabel;
	private JLabel clapLabel1;
	private JLabel clapLabel2;
	private JLabel clapLabel3;
	private JLabel[] clapLabel = {clapLabel1, clapLabel2,clapLabel3};

	public ResultPanel(MainFrame frame) {
		this.frame = frame;
		backgroundLabel = new JLabel();
		scoreLabel = new JLabel();
		clapLabel[0] = new JLabel();
		clapLabel[1] = new JLabel();
		clapLabel[2] = new JLabel();
		
		backgroundLabel.setIcon(imgBackground);
		//clapLabel[0].setIcon(imgClap);
		//clapLabel[1].setIcon(imgClap);
		//clapLabel[2].setIcon(imgClap);
		
		backgroundLabel.setBounds(0, 0, 800, 800);
		scoreLabel.setBounds(200, 100, 400, 400);
		clapLabel[0].setBounds(150,550,100,100);
		clapLabel[1].setBounds(350,550,100,100);
		clapLabel[2].setBounds(550,550,100,100);
		
		this.add(scoreLabel);
		this.add(clapLabel[0]);
		this.add(clapLabel[1]);
		this.add(clapLabel[2]);
		this.add(backgroundLabel);
		
	
	}
	
	public void printScore(){
		int score = frame.getQuizPanel().getScore();
		System.out.println("result"+score);
		
		if(score==50)
			scoreLabel.setIcon(new ImageIcon("s50.jpg"));
		else if(score==40)
			scoreLabel.setIcon(new ImageIcon("s40.jpg"));
		else if(score==30)
			scoreLabel.setIcon(new ImageIcon("s30.jpg"));
		else if(score==20)
			scoreLabel.setIcon(new ImageIcon("s20.jpg"));
		else if(score==10)
			scoreLabel.setIcon(new ImageIcon("s10.jpg"));
		else
			scoreLabel.setIcon(new ImageIcon("s0.jpg"));
		frame.getQuizPanel().setScore(0);
	}
	public void numOfClap(int i){
		clapLabel[i-1].setIcon(imgEmpty);
	}
	public void setIClapLabel(){
		clapLabel[0].setIcon(imgClap);
		clapLabel[1].setIcon(imgClap);
		clapLabel[2].setIcon(imgClap);	
	}
	
}
