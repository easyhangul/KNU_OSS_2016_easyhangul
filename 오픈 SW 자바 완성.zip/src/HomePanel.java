import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HomePanel extends JPanel {

	private JLabel backgroundLbl = null;

	public HomePanel() {
		ImageIcon backgroundIcon = new ImageIcon("home.jpg");
		backgroundLbl = new JLabel();
		backgroundLbl.setIcon(backgroundIcon);
		this.add(backgroundLbl);
		backgroundLbl.setBounds(0, 0, 800, 800);
	}
}
