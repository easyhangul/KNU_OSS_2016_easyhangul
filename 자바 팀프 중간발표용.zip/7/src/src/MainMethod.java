import java.io.IOException;

import com.leapmotion.leap.Controller;

public class MainMethod {
	
	//private static MainFrame mainFrame = new MainFrame();
	
	public static void main(String[] args){
		MainFrame mainFrame = new MainFrame();
		
		MainListener mainListener = new MainListener(mainFrame);
		Controller controller = new Controller();

		controller.addListener(mainListener);
		
		System.out.println("Press enter to quit");
		
		try{
			System.in.read();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		
		controller.removeListener(mainListener);
		
		
		
	}
	
	
	
}
