import com.leapmotion.leap.*;
import com.leapmotion.leap.Gesture.State;
import com.leapmotion.leap.Gesture.Type;

import java.io.File;
//import java.io.IOException;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class MainListener extends Listener {
	private int f_number = 0;
	private MainFrame mainFrame = null;
	private int[] lcur = new int[6];
	private int[] lprev = new int[6];
	
	//�Ҹ�
	private File C = new File("C.wav");
	private AudioInputStream ais;
	private Clip clip;

	public MainListener(MainFrame mainFrame){
		this.mainFrame = mainFrame;
	 }

	public void onInit(Controller controller) {
		System.out.println("Initialized");
	}

	public void onConnect(Controller controller) {
		System.out.println("Connected to Motion Sensor");
		controller.enableGesture(Gesture.Type.TYPE_CIRCLE);
		controller.enableGesture(Gesture.Type.TYPE_SWIPE);
		//controller.enableGesture(Gesture.Type.TYPE_KEY_TAP);
		//controller.enableGesture(Gesture.Type.TYPE_SCREEN_TAP);
	}

	public void onDisconnect(Controller controller) {
		System.out.println("Motion Sensor Disconnected");
	}

	public void onExit(Controller controller) {
		System.out.println("Exited");
	}

	public void onFrame(Controller controller) {
		Frame frame = controller.frame();
		Frame prevFrame = controller.frame(1);
		GestureList gestures = frame.gestures();
		
		int i = -1;
		
		
		

		
		for(Gesture gesture : frame.gestures()){
			 if(gesture.type() == Type.TYPE_SWIPE && 
				gesture.state() == State.STATE_START){
			System.out.println("s");
			mainFrame.changePanel();
			 
		}else if(gesture.type() == Type.TYPE_CIRCLE && gesture.state() == State.STATE_STOP){
			System.out.println("c");
			try {
				ais = AudioSystem.getAudioInputStream(C);
				clip = AudioSystem.getClip();
				clip.open(ais);
				clip.start();
			} catch (UnsupportedAudioFileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (LineUnavailableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//mainFrame.changePanel();

	}else if(gesture.type() == Type.TYPE_SCREEN_TAP){
			System.out.println("t");
		}
		}
		/*
		while(true){
			Gesture gesture = gestures.get(0);
			switch(gesture.type()){
			case TYPE_SWIPE:
				System.out.println("g");
				//mainFrame.changePanel();
				break;
			case TYPE_CIRCLE:
				System.out.printf("c");
			}
		}*/
	}
}
