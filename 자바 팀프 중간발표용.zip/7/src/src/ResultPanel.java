import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ResultPanel extends JPanel{

	private JLabel startLbl = null;
	private MainFrame mainFrame = null;
			
	public ResultPanel(MainFrame mainFrame) {
		
				//
				//this.mainFrame = mainFrame;
				//
				//Thread difficultyThread = new Thread(new DifficultyThread());
				//difficultyThread.start();
				
				ImageIcon startIcon = new ImageIcon("r.jpg");
				startLbl = new JLabel();
				//startLbl.setBounds(0, 0, 50, 50);
				startLbl.setIcon(startIcon);
				this.add(startLbl);
				this.setSize(500, 500);
			}
	}

