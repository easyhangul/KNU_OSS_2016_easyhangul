import javax.swing.*;

import com.leapmotion.leap.Controller;

import java.awt.FlowLayout;
import java.awt.event.*;

public class MainFrame extends JFrame {

	
	private HomePanel homePanel = new HomePanel(this);
	private HowToPanel howToPanel = new HowToPanel(this);
	private DifficultyPanel difficultyPanel = new DifficultyPanel(this);
	private QuizPanel quizPanel = new QuizPanel(this);
	private ResultPanel resultPanel = new ResultPanel(this);
	
	private JPanel[] panelArr = {homePanel, howToPanel, difficultyPanel, quizPanel, resultPanel};

	private JPanel currentPanel = null;

	public MainFrame() {
		// ������ ����
		//setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setLayout(null);
		this.setSize(500, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("�ѱ� ����� ����");
		
	
		//currentPanel = homePanel;
		currentPanel = panelArr[0];
		currentPanel.setSize(500, 500);
		
		this.setContentPane(currentPanel);
		this.setVisible(true);
		this.setResizable(false);
		
		//Thread homeThread = new Thread(new HomeThread());
		//homeThread.start();
		/*
		 * //��ư1 ���� panel = new JPanel(); //panel.setBounds(150, 150, 200, 200);
		 * ImageIcon startIcon = new ImageIcon("quiz_home.jpg"); button = new
		 * JButton(); button.setSize(200, 200); button.setIcon(startIcon);
		 * button.setText(null); panel.add(button);
		 * 
		 * //�̹���1 ���� imgPnl1 = new JPanel(); img1 = new JLabel(); ImageIcon
		 * imgIcon1 = new ImageIcon("�������.jpg"); img1.setSize(200, 200);
		 * img1.setIcon(imgIcon1); img1.setText(null); imgPnl1.add(img1);
		 * 
		 * add(panel); add(imgPnl1); setVisible(true);
		 * 
		 * button.addActionListener(new MyListener());
		 */
		
	}

	public synchronized void changePanel(){
		int i;
		for(i=0; i<5; i++)
			if(currentPanel == panelArr[i])
				break;
		
		currentPanel = panelArr[(i+1)%5];
		
		/*if(currentPanel == panelArr[0]){
			panelArr[0] = null;
			panelArr[1] = new HowToPanel(this);
			currentPanel = panelArr[0];
		}*/
		//JLabel label = new JLabel();
		//label.setIcon(new ImageIcon("1.jpg"));
		//currentPanel.add(label);
		setContentPane(currentPanel);
		currentPanel.setBounds(0, 0, 500, 500);
		//currentPanel.setSize(500, 500);
		currentPanel.setVisible(true);
		//this.repaint();
	}

}
