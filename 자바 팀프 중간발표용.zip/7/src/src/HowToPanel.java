import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class HowToPanel extends JPanel{
	
	private JLabel startLbl = null;
	private MainFrame mainFrame = null;
	
	public HowToPanel(MainFrame mainFrame){
		//
		//this.mainFrame = mainFrame;
		//
		//Thread howToThread = new Thread(new HowToThread());
		//howToThread.start();
		
		ImageIcon startIcon = new ImageIcon("1.jpg");
		startLbl = new JLabel();
		//startLbl.setBounds(0, 0, 50, 50);
		startLbl.setIcon(startIcon);
		this.add(startLbl);
		this.setSize(500, 500);
	}
	

}
