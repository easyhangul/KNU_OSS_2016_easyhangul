import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class QuizPanel extends JPanel{


	private JLabel startLbl = null;
	private MainFrame mainFrame = null;
			
	public QuizPanel(MainFrame mainFrame) {
		
				//
				//this.mainFrame = mainFrame;
				//
				//Thread difficultyThread = new Thread(new DifficultyThread());
				//difficultyThread.start();
				
				ImageIcon startIcon = new ImageIcon("q.jpg");
				startLbl = new JLabel();
				//startLbl.setBounds(0, 0, 50, 50);
				startLbl.setIcon(startIcon);
				this.add(startLbl);
				this.setSize(500, 500);
			}
	}