import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class DifficultyPanel extends JPanel{
	
	private JLabel startLbl = null;
	private MainFrame mainFrame = null;
	
	public DifficultyPanel(MainFrame mainFrame) {
	
			//
			//this.mainFrame = mainFrame;
			//
			//Thread difficultyThread = new Thread(new DifficultyThread());
			//difficultyThread.start();
			
			ImageIcon startIcon = new ImageIcon("d.jpg");
			startLbl = new JLabel();
			//startLbl.setBounds(0, 0, 50, 50);
			startLbl.setIcon(startIcon);
			this.add(startLbl);
			this.setSize(500, 500);
		}

	}
	
