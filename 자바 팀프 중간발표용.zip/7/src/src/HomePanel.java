import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.leapmotion.leap.Controller;

public class HomePanel extends JPanel{
	
	//private JLabel startLbl = null;
	private JButton startBtn = null;
	private MainFrame mainFrame = null;
	
	public HomePanel(MainFrame mainFrame){

		this.mainFrame = mainFrame;
		
		//Thread homeThread = new Thread(new HomeThread());
		//homeThread.start();
		
		ImageIcon startIcon = new ImageIcon("quiz_home.jpg");
		startBtn = new JButton();
		startBtn.setSize(200, 200);
		startBtn.setIcon(startIcon);
		//startBtn.addActionListener(new HomeListener());
		this.add(startBtn);
		
		
		
		//startLbl = new JLabel();
		//startLbl.setIcon(startIcon);
		//startLbl.addMouseListener((MouseListener) startLbl);
		//this.add(startLbl);
		//this.addActionListener(new HomeListener());
	}
	
	class HomeThread implements Runnable{
		public void run(){
			MainListener mainListener = new MainListener(mainFrame);
			Controller controller = new Controller();

			controller.addListener(mainListener);
			}
		}
	
	
	private class HomeListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == startBtn){
				mainFrame.changePanel();
			}
		}
	}
	
}
