
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class Menu extends JPanel {
	private Frame frame;
	
	private JButton buttonEasy;
	private JButton buttonNormal;
	private JButton buttonHard;

	Icon menu1 = new ImageIcon(getClass().getResource("baby.jpg"));
	Icon menu2 = new ImageIcon(getClass().getResource("child.jpg"));
	Icon menu3 = new ImageIcon(getClass().getResource("student.jpg"));
	
	public Menu(Frame frame){
		this.frame = frame;
		this.setBounds(0,0,500,500);
		this.setLayout(new FlowLayout());
	
		//add(menuPanel);
		buttonEasy = new JButton("easy",menu1);
		buttonNormal = new JButton("Normal",menu2);
		buttonHard = new JButton("Hard",menu3);
		
		this.add(buttonEasy);
		this.add(buttonNormal);
		this.add(buttonHard);
		
		ButtonHandler handler = new ButtonHandler();
		buttonEasy.addActionListener(handler);
		buttonNormal.addActionListener(handler);
		buttonHard.addActionListener(handler);

	}
	
private class ButtonHandler implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent event){
			//��ư �������� �ൿ
			if(event.getSource()==buttonEasy){
				
			}
			else if(event.getSource()==buttonNormal){
				
			}
			else if(event.getSource()==buttonHard){
				
			}
		}
	}
}
