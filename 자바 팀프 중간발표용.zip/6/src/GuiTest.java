
public class GuiTest{
	
	public static void main(String[] args) {
		Frame frmWindows = new Frame("�ѱ� �� 10��?");
	}
}
