import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Start extends JPanel{
	
	private Frame frame;

	private JButton buttonStart;
	
	
	public Start(Frame frame){
		this.frame = frame;	
		this.setBounds(200,400,100,50);
		
		buttonStart = new JButton("start");
		this.add(buttonStart);
		ButtonHandler handler = new ButtonHandler();
		buttonStart.addActionListener(handler);	
	}
	
private class ButtonHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event){
			
			//��ư �������� �ൿ
			if(event.getSource()==buttonStart){
				frame.changePanel();
				}
		}
	}
	
}

